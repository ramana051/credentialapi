"""
Design Studio Service

This service handles credential template design and management,
providing a drag-and-drop interface for creating custom certificate and badge templates.
"""

from fastapi import FastAPI, Depends, HTTPException, status, UploadFile, File, Form, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from datetime import datetime
import json
import os
import uuid
from pathlib import Path
import shutil

# Import shared modules
import sys
sys.path.append('/home/ubuntu/digital-credentials-platform/backend')

from shared.database import get_db_session, create_tables
from shared.models import CredentialTemplate, User, Organization, TemplateStatus, UserRole
from shared.auth import get_current_user, require_roles, PermissionChecker
from shared.exceptions import ValidationError, NotFoundError, AuthorizationError, TemplateError
from shared.utils import generate_uuid, sanitize_filename
from shared.config import settings

# Pydantic models
from pydantic import BaseModel, validator
from enum import Enum


class TemplateCreateRequest(BaseModel):
    name: str
    description: Optional[str] = None
    template_type: str  # certificate, badge, diploma
    organization_id: str
    design_data: Dict[str, Any]
    fields_schema: Dict[str, Any]
    is_public: bool = False
    tags: Optional[List[str]] = []
    
    @validator('name')
    def validate_name(cls, v):
        if len(v.strip()) < 3:
            raise ValueError('Template name must be at least 3 characters long')
        return v.strip()
    
    @validator('template_type')
    def validate_template_type(cls, v):
        valid_types = ['certificate', 'badge', 'diploma']
        if v not in valid_types:
            raise ValueError(f'Template type must be one of: {valid_types}')
        return v


class TemplateUpdateRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    design_data: Optional[Dict[str, Any]] = None
    fields_schema: Optional[Dict[str, Any]] = None
    is_public: Optional[bool] = None
    tags: Optional[List[str]] = None


class TemplateResponse(BaseModel):
    id: str
    name: str
    description: Optional[str]
    template_type: str
    organization_id: str
    creator_id: str
    design_data: Dict[str, Any]
    fields_schema: Dict[str, Any]
    status: str
    is_public: bool
    version: int
    tags: Optional[List[str]]
    created_at: datetime
    updated_at: Optional[datetime]
    
    class Config:
        from_attributes = True


class AssetUploadResponse(BaseModel):
    asset_id: str
    filename: str
    url: str
    file_type: str
    file_size: int


# Initialize FastAPI app
app = FastAPI(
    title="Digital Credentials Platform - Design Studio Service",
    description="Service for designing and managing credential templates",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create directories
assets_dir = Path(settings.upload_directory) / "assets"
templates_dir = Path(settings.upload_directory) / "templates"
assets_dir.mkdir(parents=True, exist_ok=True)
templates_dir.mkdir(parents=True, exist_ok=True)

# Mount static files
app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")


@app.on_event("startup")
async def startup_event():
    """Initialize database tables on startup."""
    create_tables()


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "design-studio"}


@app.post("/templates", response_model=TemplateResponse)
async def create_template(
    request: TemplateCreateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Create a new credential template."""
    
    # Check permissions
    permission_checker = PermissionChecker(current_user, db)
    if not permission_checker.can_manage_templates(request.organization_id):
        raise AuthorizationError("You don't have permission to create templates for this organization")
    
    # Validate organization exists
    organization = db.query(Organization).filter(
        Organization.id == request.organization_id
    ).first()
    
    if not organization:
        raise NotFoundError("Organization not found")
    
    # Create template
    template = CredentialTemplate(
        name=request.name,
        description=request.description,
        template_type=request.template_type,
        organization_id=request.organization_id,
        creator_id=current_user.id,
        design_data=request.design_data,
        fields_schema=request.fields_schema,
        status=TemplateStatus.DRAFT,
        is_public=request.is_public,
        tags=request.tags or []
    )
    
    db.add(template)
    db.commit()
    db.refresh(template)
    
    return TemplateResponse.from_orm(template)


@app.get("/templates", response_model=List[TemplateResponse])
async def list_templates(
    organization_id: Optional[str] = None,
    template_type: Optional[str] = None,
    status: Optional[str] = None,
    is_public: Optional[bool] = None,
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """List credential templates with filtering options."""
    
    query = db.query(CredentialTemplate)
    
    # Apply access control
    if current_user.role == UserRole.SUPER_ADMIN:
        # Super admin can see all templates
        pass
    else:
        # Other users can only see public templates or templates from their organizations
        if organization_id:
            permission_checker = PermissionChecker(current_user, db)
            if not permission_checker.can_manage_templates(organization_id):
                # Can only see public templates from this organization
                query = query.filter(
                    CredentialTemplate.organization_id == organization_id,
                    CredentialTemplate.is_public == True
                )
            else:
                # Can see all templates from this organization
                query = query.filter(CredentialTemplate.organization_id == organization_id)
        else:
            # Show public templates and templates from user's organizations
            from shared.models import OrganizationMember
            user_org_ids = db.query(OrganizationMember.organization_id).filter(
                OrganizationMember.user_id == current_user.id
            ).subquery()
            
            query = query.filter(
                (CredentialTemplate.is_public == True) |
                (CredentialTemplate.organization_id.in_(user_org_ids))
            )
    
    # Apply filters
    if template_type:
        query = query.filter(CredentialTemplate.template_type == template_type)
    
    if status:
        query = query.filter(CredentialTemplate.status == status)
    
    if is_public is not None:
        query = query.filter(CredentialTemplate.is_public == is_public)
    
    # Apply pagination
    templates = query.offset(skip).limit(limit).all()
    
    return [TemplateResponse.from_orm(template) for template in templates]


@app.get("/templates/{template_id}", response_model=TemplateResponse)
async def get_template(
    template_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Get a specific template."""
    
    template = db.query(CredentialTemplate).filter(
        CredentialTemplate.id == template_id
    ).first()
    
    if not template:
        raise NotFoundError("Template not found")
    
    # Check access permissions
    if not template.is_public and current_user.role != UserRole.SUPER_ADMIN:
        permission_checker = PermissionChecker(current_user, db)
        if not permission_checker.can_manage_templates(str(template.organization_id)):
            raise AuthorizationError("Access denied to this template")
    
    return TemplateResponse.from_orm(template)


@app.put("/templates/{template_id}", response_model=TemplateResponse)
async def update_template(
    template_id: str,
    request: TemplateUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Update a template."""
    
    template = db.query(CredentialTemplate).filter(
        CredentialTemplate.id == template_id
    ).first()
    
    if not template:
        raise NotFoundError("Template not found")
    
    # Check permissions
    permission_checker = PermissionChecker(current_user, db)
    if not permission_checker.can_manage_templates(str(template.organization_id)):
        raise AuthorizationError("You don't have permission to modify this template")
    
    # Update fields
    if request.name is not None:
        template.name = request.name
    if request.description is not None:
        template.description = request.description
    if request.design_data is not None:
        template.design_data = request.design_data
        template.version += 1  # Increment version on design changes
    if request.fields_schema is not None:
        template.fields_schema = request.fields_schema
    if request.is_public is not None:
        template.is_public = request.is_public
    if request.tags is not None:
        template.tags = request.tags
    
    template.updated_at = datetime.utcnow()
    
    db.commit()
    db.refresh(template)
    
    return TemplateResponse.from_orm(template)


@app.post("/templates/{template_id}/publish")
async def publish_template(
    template_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Publish a template (change status from draft to active)."""
    
    template = db.query(CredentialTemplate).filter(
        CredentialTemplate.id == template_id
    ).first()
    
    if not template:
        raise NotFoundError("Template not found")
    
    # Check permissions
    permission_checker = PermissionChecker(current_user, db)
    if not permission_checker.can_manage_templates(str(template.organization_id)):
        raise AuthorizationError("You don't have permission to publish this template")
    
    if template.status != TemplateStatus.DRAFT:
        raise TemplateError("Only draft templates can be published")
    
    # Validate template before publishing
    validation_result = validate_template_design(template.design_data, template.fields_schema)
    if not validation_result["valid"]:
        raise TemplateError(f"Template validation failed: {validation_result['errors']}")
    
    template.status = TemplateStatus.ACTIVE
    template.updated_at = datetime.utcnow()
    
    db.commit()
    
    return {"message": "Template published successfully", "template_id": template_id}


@app.post("/templates/{template_id}/duplicate", response_model=TemplateResponse)
async def duplicate_template(
    template_id: str,
    name: str = Form(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Duplicate an existing template."""
    
    original_template = db.query(CredentialTemplate).filter(
        CredentialTemplate.id == template_id
    ).first()
    
    if not original_template:
        raise NotFoundError("Template not found")
    
    # Check access to original template
    if not original_template.is_public and current_user.role != UserRole.SUPER_ADMIN:
        permission_checker = PermissionChecker(current_user, db)
        if not permission_checker.can_manage_templates(str(original_template.organization_id)):
            raise AuthorizationError("Access denied to this template")
    
    # Check permission to create in the same organization
    permission_checker = PermissionChecker(current_user, db)
    if not permission_checker.can_manage_templates(str(original_template.organization_id)):
        raise AuthorizationError("You don't have permission to create templates in this organization")
    
    # Create duplicate
    duplicate_template = CredentialTemplate(
        name=name,
        description=f"Copy of {original_template.name}",
        template_type=original_template.template_type,
        organization_id=original_template.organization_id,
        creator_id=current_user.id,
        design_data=original_template.design_data.copy(),
        fields_schema=original_template.fields_schema.copy(),
        status=TemplateStatus.DRAFT,
        is_public=False,  # Duplicates start as private
        tags=original_template.tags.copy() if original_template.tags else []
    )
    
    db.add(duplicate_template)
    db.commit()
    db.refresh(duplicate_template)
    
    return TemplateResponse.from_orm(duplicate_template)


@app.delete("/templates/{template_id}")
async def delete_template(
    template_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Delete a template (archive it)."""
    
    template = db.query(CredentialTemplate).filter(
        CredentialTemplate.id == template_id
    ).first()
    
    if not template:
        raise NotFoundError("Template not found")
    
    # Check permissions
    permission_checker = PermissionChecker(current_user, db)
    if not permission_checker.can_manage_templates(str(template.organization_id)):
        raise AuthorizationError("You don't have permission to delete this template")
    
    # Check if template is being used
    from shared.models import Credential
    credentials_count = db.query(Credential).filter(
        Credential.template_id == template.id
    ).count()
    
    if credentials_count > 0:
        # Archive instead of delete if template is in use
        template.status = TemplateStatus.ARCHIVED
        template.updated_at = datetime.utcnow()
        db.commit()
        return {"message": "Template archived successfully (was in use)", "template_id": template_id}
    else:
        # Safe to delete
        db.delete(template)
        db.commit()
        return {"message": "Template deleted successfully", "template_id": template_id}


@app.post("/assets/upload", response_model=AssetUploadResponse)
async def upload_asset(
    file: UploadFile = File(...),
    asset_type: str = Form(...),  # logo, signature, background, icon
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Upload an asset for use in templates."""
    
    # Validate file type
    allowed_types = {
        'logo': ['image/png', 'image/jpeg', 'image/svg+xml'],
        'signature': ['image/png', 'image/jpeg'],
        'background': ['image/png', 'image/jpeg'],
        'icon': ['image/png', 'image/svg+xml']
    }
    
    if asset_type not in allowed_types:
        raise ValidationError(f"Invalid asset type: {asset_type}")
    
    if file.content_type not in allowed_types[asset_type]:
        raise ValidationError(f"Invalid file type for {asset_type}: {file.content_type}")
    
    # Check file size (max 5MB)
    if file.size and file.size > 5 * 1024 * 1024:
        raise ValidationError("File size too large (max 5MB)")
    
    # Generate unique filename
    asset_id = str(uuid.uuid4())
    file_extension = file.filename.split('.')[-1] if '.' in file.filename else 'png'
    filename = f"{asset_id}.{file_extension}"
    
    # Create asset directory for user/organization
    user_assets_dir = assets_dir / str(current_user.id)
    user_assets_dir.mkdir(exist_ok=True)
    
    # Save file
    file_path = user_assets_dir / filename
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    # Generate URL
    asset_url = f"/assets/{current_user.id}/{filename}"
    
    return AssetUploadResponse(
        asset_id=asset_id,
        filename=file.filename,
        url=asset_url,
        file_type=file.content_type,
        file_size=file.size or 0
    )


@app.get("/templates/default-designs")
async def get_default_designs():
    """Get default template designs."""
    
    default_designs = {
        "certificate": {
            "name": "Classic Certificate",
            "design_data": {
                "layout": "landscape",
                "width": 1200,
                "height": 800,
                "background": {
                    "type": "color",
                    "value": "#ffffff"
                },
                "border": {
                    "enabled": True,
                    "style": "solid",
                    "width": 3,
                    "color": "#2563EB"
                },
                "elements": [
                    {
                        "id": "title",
                        "type": "text",
                        "content": "CERTIFICATE OF ACHIEVEMENT",
                        "x": 600,
                        "y": 100,
                        "width": 800,
                        "height": 60,
                        "style": {
                            "fontSize": 36,
                            "fontFamily": "Arial",
                            "fontWeight": "bold",
                            "color": "#2563EB",
                            "textAlign": "center"
                        }
                    },
                    {
                        "id": "recipient_name",
                        "type": "text",
                        "content": "{{recipient_name}}",
                        "x": 600,
                        "y": 300,
                        "width": 600,
                        "height": 50,
                        "style": {
                            "fontSize": 28,
                            "fontFamily": "Arial",
                            "fontWeight": "bold",
                            "color": "#1F2937",
                            "textAlign": "center"
                        }
                    },
                    {
                        "id": "description",
                        "type": "text",
                        "content": "{{description}}",
                        "x": 600,
                        "y": 400,
                        "width": 800,
                        "height": 100,
                        "style": {
                            "fontSize": 16,
                            "fontFamily": "Arial",
                            "color": "#374151",
                            "textAlign": "center"
                        }
                    },
                    {
                        "id": "issue_date",
                        "type": "text",
                        "content": "Issued on {{issue_date}}",
                        "x": 600,
                        "y": 600,
                        "width": 400,
                        "height": 30,
                        "style": {
                            "fontSize": 14,
                            "fontFamily": "Arial",
                            "color": "#6B7280",
                            "textAlign": "center"
                        }
                    }
                ]
            },
            "fields_schema": {
                "recipient_name": {"type": "string", "required": True, "label": "Recipient Name"},
                "description": {"type": "string", "required": True, "label": "Achievement Description"},
                "issue_date": {"type": "date", "required": True, "label": "Issue Date"}
            }
        },
        "badge": {
            "name": "Digital Badge",
            "design_data": {
                "layout": "square",
                "width": 400,
                "height": 400,
                "background": {
                    "type": "gradient",
                    "value": "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
                },
                "elements": [
                    {
                        "id": "badge_icon",
                        "type": "icon",
                        "content": "🏆",
                        "x": 200,
                        "y": 120,
                        "width": 80,
                        "height": 80,
                        "style": {
                            "fontSize": 60,
                            "textAlign": "center"
                        }
                    },
                    {
                        "id": "title",
                        "type": "text",
                        "content": "{{title}}",
                        "x": 200,
                        "y": 220,
                        "width": 300,
                        "height": 40,
                        "style": {
                            "fontSize": 18,
                            "fontFamily": "Arial",
                            "fontWeight": "bold",
                            "color": "#ffffff",
                            "textAlign": "center"
                        }
                    },
                    {
                        "id": "recipient_name",
                        "type": "text",
                        "content": "{{recipient_name}}",
                        "x": 200,
                        "y": 280,
                        "width": 300,
                        "height": 30,
                        "style": {
                            "fontSize": 14,
                            "fontFamily": "Arial",
                            "color": "#ffffff",
                            "textAlign": "center"
                        }
                    }
                ]
            },
            "fields_schema": {
                "title": {"type": "string", "required": True, "label": "Badge Title"},
                "recipient_name": {"type": "string", "required": True, "label": "Recipient Name"}
            }
        }
    }
    
    return default_designs


def validate_template_design(design_data: Dict[str, Any], fields_schema: Dict[str, Any]) -> Dict[str, Any]:
    """Validate template design data."""
    
    errors = []
    warnings = []
    
    # Check required fields
    required_fields = ['layout', 'width', 'height', 'elements']
    for field in required_fields:
        if field not in design_data:
            errors.append(f"Missing required field: {field}")
    
    # Validate elements
    if 'elements' in design_data:
        for i, element in enumerate(design_data['elements']):
            element_errors = validate_element(element, i)
            errors.extend(element_errors)
    
    # Check field schema consistency
    if 'elements' in design_data:
        template_fields = set()
        for element in design_data['elements']:
            if element.get('type') == 'text' and '{{' in element.get('content', ''):
                # Extract field names from template variables
                import re
                field_matches = re.findall(r'\{\{(\w+)\}\}', element.get('content', ''))
                template_fields.update(field_matches)
        
        schema_fields = set(fields_schema.keys())
        missing_schema = template_fields - schema_fields
        unused_schema = schema_fields - template_fields
        
        if missing_schema:
            warnings.append(f"Template uses fields not in schema: {missing_schema}")
        if unused_schema:
            warnings.append(f"Schema defines unused fields: {unused_schema}")
    
    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings
    }


def validate_element(element: Dict[str, Any], index: int) -> List[str]:
    """Validate a single template element."""
    
    errors = []
    
    # Check required fields
    required_fields = ['id', 'type', 'x', 'y', 'width', 'height']
    for field in required_fields:
        if field not in element:
            errors.append(f"Element {index}: Missing required field '{field}'")
    
    # Validate element type
    valid_types = ['text', 'image', 'icon', 'shape', 'qr_code']
    if 'type' in element and element['type'] not in valid_types:
        errors.append(f"Element {index}: Invalid type '{element['type']}'")
    
    # Validate coordinates and dimensions
    numeric_fields = ['x', 'y', 'width', 'height']
    for field in numeric_fields:
        if field in element:
            try:
                float(element[field])
            except (ValueError, TypeError):
                errors.append(f"Element {index}: '{field}' must be numeric")
    
    return errors


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

