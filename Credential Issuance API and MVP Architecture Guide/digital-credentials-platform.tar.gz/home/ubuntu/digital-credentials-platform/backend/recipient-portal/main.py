"""
Recipient Portal Service

This service handles the recipient/earner portal functionality,
allowing credential holders to view, manage, and share their credentials.
"""

from fastapi import FastAPI, Depends, HTTPException, status, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import json
import os
from pathlib import Path

# Import shared modules
import sys
sys.path.append('/home/ubuntu/digital-credentials-platform/backend')

from shared.database import get_db_session, create_tables
from shared.models import (
    Credential, User, Organization, CredentialStatus, 
    AnalyticsEvent, SocialShare, SharePlatform
)
from shared.auth import get_current_user, get_optional_user
from shared.exceptions import NotFoundError, AuthorizationError
from shared.utils import generate_uuid
from shared.config import settings

# Pydantic models
from pydantic import BaseModel, validator
from enum import Enum


class RecipientCredentialResponse(BaseModel):
    id: str
    credential_id: str
    title: str
    description: Optional[str]
    organization_name: str
    organization_logo: Optional[str]
    issuer_name: str
    issued_at: Optional[datetime]
    expires_at: Optional[datetime]
    status: str
    is_public: bool
    verification_url: str
    pdf_url: Optional[str]
    png_url: Optional[str]
    tags: Optional[List[str]]
    
    class Config:
        from_attributes = True


class RecipientProfileResponse(BaseModel):
    id: str
    first_name: str
    last_name: str
    email: str
    profile_picture: Optional[str]
    bio: Optional[str]
    location: Optional[str]
    website: Optional[str]
    linkedin_url: Optional[str]
    twitter_url: Optional[str]
    is_public: bool
    total_credentials: int
    public_credentials: int
    
    class Config:
        from_attributes = True


class RecipientProfileUpdateRequest(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    bio: Optional[str] = None
    location: Optional[str] = None
    website: Optional[str] = None
    linkedin_url: Optional[str] = None
    twitter_url: Optional[str] = None
    is_public: Optional[bool] = None


class CredentialPrivacyUpdateRequest(BaseModel):
    credential_ids: List[str]
    is_public: bool


class EarnerDirectoryEntry(BaseModel):
    id: str
    name: str
    bio: Optional[str]
    location: Optional[str]
    profile_picture: Optional[str]
    total_credentials: int
    recent_credentials: List[Dict[str, Any]]
    
    class Config:
        from_attributes = True


class ShareCredentialRequest(BaseModel):
    platform: str
    message: Optional[str] = None
    
    @validator('platform')
    def validate_platform(cls, v):
        valid_platforms = ['linkedin', 'twitter', 'facebook', 'email', 'whatsapp']
        if v not in valid_platforms:
            raise ValueError(f'Platform must be one of: {valid_platforms}')
        return v


# Initialize FastAPI app
app = FastAPI(
    title="Digital Credentials Platform - Recipient Portal Service",
    description="Service for recipient credential management and earners directory",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    """Initialize database tables on startup."""
    create_tables()


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "recipient-portal"}


@app.get("/profile", response_model=RecipientProfileResponse)
async def get_recipient_profile(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Get the current user's profile information."""
    
    # Count credentials
    total_credentials = db.query(Credential).filter(
        Credential.recipient_email == current_user.email
    ).count()
    
    public_credentials = db.query(Credential).filter(
        and_(
            Credential.recipient_email == current_user.email,
            Credential.is_public == True
        )
    ).count()
    
    return RecipientProfileResponse(
        id=str(current_user.id),
        first_name=current_user.first_name,
        last_name=current_user.last_name,
        email=current_user.email,
        profile_picture=current_user.profile_picture,
        bio=current_user.bio,
        location=current_user.location,
        website=current_user.website,
        linkedin_url=current_user.linkedin_url,
        twitter_url=current_user.twitter_url,
        is_public=current_user.is_public,
        total_credentials=total_credentials,
        public_credentials=public_credentials
    )


@app.put("/profile", response_model=RecipientProfileResponse)
async def update_recipient_profile(
    request: RecipientProfileUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Update the current user's profile information."""
    
    # Update fields
    if request.first_name is not None:
        current_user.first_name = request.first_name
    if request.last_name is not None:
        current_user.last_name = request.last_name
    if request.bio is not None:
        current_user.bio = request.bio
    if request.location is not None:
        current_user.location = request.location
    if request.website is not None:
        current_user.website = request.website
    if request.linkedin_url is not None:
        current_user.linkedin_url = request.linkedin_url
    if request.twitter_url is not None:
        current_user.twitter_url = request.twitter_url
    if request.is_public is not None:
        current_user.is_public = request.is_public
    
    current_user.updated_at = datetime.utcnow()
    
    db.commit()
    db.refresh(current_user)
    
    # Return updated profile
    return await get_recipient_profile(current_user, db)


@app.get("/credentials", response_model=List[RecipientCredentialResponse])
async def get_recipient_credentials(
    status: Optional[str] = None,
    organization_id: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Get credentials for the current recipient."""
    
    query = db.query(Credential).filter(
        Credential.recipient_email == current_user.email
    )
    
    # Apply filters
    if status:
        query = query.filter(Credential.status == status)
    
    if organization_id:
        query = query.filter(Credential.organization_id == organization_id)
    
    # Order by issue date (newest first)
    query = query.order_by(desc(Credential.issued_at))
    
    # Apply pagination
    credentials = query.offset(skip).limit(limit).all()
    
    # Convert to response format
    result = []
    for credential in credentials:
        organization = credential.organization
        issuer = credential.issuer
        
        result.append(RecipientCredentialResponse(
            id=str(credential.id),
            credential_id=credential.credential_id,
            title=credential.title,
            description=credential.description,
            organization_name=organization.name,
            organization_logo=organization.logo_url,
            issuer_name=f"{issuer.first_name} {issuer.last_name}",
            issued_at=credential.issued_at,
            expires_at=credential.expires_at,
            status=credential.status.value,
            is_public=credential.is_public,
            verification_url=credential.verification_url,
            pdf_url=credential.pdf_url,
            png_url=credential.png_url,
            tags=credential.tags
        ))
    
    return result


@app.get("/credentials/{credential_id}", response_model=RecipientCredentialResponse)
async def get_recipient_credential(
    credential_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Get a specific credential for the current recipient."""
    
    credential = db.query(Credential).filter(
        and_(
            Credential.credential_id == credential_id,
            Credential.recipient_email == current_user.email
        )
    ).first()
    
    if not credential:
        raise NotFoundError("Credential not found")
    
    organization = credential.organization
    issuer = credential.issuer
    
    return RecipientCredentialResponse(
        id=str(credential.id),
        credential_id=credential.credential_id,
        title=credential.title,
        description=credential.description,
        organization_name=organization.name,
        organization_logo=organization.logo_url,
        issuer_name=f"{issuer.first_name} {issuer.last_name}",
        issued_at=credential.issued_at,
        expires_at=credential.expires_at,
        status=credential.status.value,
        is_public=credential.is_public,
        verification_url=credential.verification_url,
        pdf_url=credential.pdf_url,
        png_url=credential.png_url,
        tags=credential.tags
    )


@app.put("/credentials/privacy")
async def update_credentials_privacy(
    request: CredentialPrivacyUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Update privacy settings for multiple credentials."""
    
    # Verify all credentials belong to the current user
    credentials = db.query(Credential).filter(
        and_(
            Credential.credential_id.in_(request.credential_ids),
            Credential.recipient_email == current_user.email
        )
    ).all()
    
    if len(credentials) != len(request.credential_ids):
        raise NotFoundError("Some credentials not found or not owned by user")
    
    # Update privacy settings
    for credential in credentials:
        credential.is_public = request.is_public
        credential.updated_at = datetime.utcnow()
    
    db.commit()
    
    return {
        "message": f"Privacy updated for {len(credentials)} credentials",
        "updated_count": len(credentials)
    }


@app.post("/credentials/{credential_id}/share")
async def share_credential(
    credential_id: str,
    request: ShareCredentialRequest,
    client_request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Share a credential on social media or via other platforms."""
    
    # Verify credential ownership
    credential = db.query(Credential).filter(
        and_(
            Credential.credential_id == credential_id,
            Credential.recipient_email == current_user.email
        )
    ).first()
    
    if not credential:
        raise NotFoundError("Credential not found")
    
    # Generate share URLs
    verification_url = credential.verification_url
    share_text = request.message or f"I just earned: {credential.title}"
    
    share_urls = {
        'linkedin': f"https://www.linkedin.com/sharing/share-offsite/?url={verification_url}",
        'twitter': f"https://twitter.com/intent/tweet?text={share_text}&url={verification_url}",
        'facebook': f"https://www.facebook.com/sharer/sharer.php?u={verification_url}",
        'whatsapp': f"https://wa.me/?text={share_text} {verification_url}",
        'email': f"mailto:?subject=Check out my credential&body={share_text} {verification_url}"
    }
    
    # Record share event
    share_record = SocialShare(
        credential_id=credential.id,
        user_id=current_user.id,
        platform=SharePlatform(request.platform),
        share_url=share_urls.get(request.platform, verification_url),
        message=request.message
    )
    
    db.add(share_record)
    
    # Record analytics event
    analytics_event = AnalyticsEvent(
        event_type="share",
        credential_id=credential.id,
        organization_id=credential.organization_id,
        event_data={
            "platform": request.platform,
            "message": request.message,
            "user_id": str(current_user.id)
        },
        ip_address=client_request.client.host if client_request.client else "unknown",
        user_agent=client_request.headers.get("user-agent", "unknown")
    )
    
    db.add(analytics_event)
    db.commit()
    
    return {
        "share_url": share_urls.get(request.platform, verification_url),
        "platform": request.platform,
        "message": "Credential shared successfully"
    }


@app.get("/credentials/{credential_id}/download/{file_type}")
async def download_credential_file(
    credential_id: str,
    file_type: str,  # pdf or png
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Download credential file (PDF or PNG)."""
    
    # Verify credential ownership
    credential = db.query(Credential).filter(
        and_(
            Credential.credential_id == credential_id,
            Credential.recipient_email == current_user.email
        )
    ).first()
    
    if not credential:
        raise NotFoundError("Credential not found")
    
    # Get file URL
    if file_type == "pdf":
        file_url = credential.pdf_url
    elif file_type == "png":
        file_url = credential.png_url
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid file type. Must be 'pdf' or 'png'"
        )
    
    if not file_url:
        raise NotFoundError(f"{file_type.upper()} file not available for this credential")
    
    # Convert URL to file path (assuming local storage)
    file_path = file_url.replace('/uploads/', settings.upload_directory + '/')
    
    if not os.path.exists(file_path):
        raise NotFoundError("File not found on server")
    
    # Record download event
    analytics_event = AnalyticsEvent(
        event_type="download",
        credential_id=credential.id,
        organization_id=credential.organization_id,
        event_data={
            "file_type": file_type,
            "user_id": str(current_user.id)
        },
        ip_address="localhost",  # Internal download
        user_agent="recipient-portal"
    )
    
    db.add(analytics_event)
    db.commit()
    
    return FileResponse(
        path=file_path,
        filename=f"{credential.title}.{file_type}",
        media_type=f"application/{file_type}" if file_type == "pdf" else "image/png"
    )


@app.get("/directory", response_model=List[EarnerDirectoryEntry])
async def get_earners_directory(
    search: Optional[str] = None,
    location: Optional[str] = None,
    organization_id: Optional[str] = None,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db_session)
):
    """Get the public earners directory."""
    
    # Base query for public profiles
    query = db.query(User).filter(User.is_public == True)
    
    # Apply search filter
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            or_(
                User.first_name.ilike(search_term),
                User.last_name.ilike(search_term),
                User.bio.ilike(search_term)
            )
        )
    
    # Apply location filter
    if location:
        query = query.filter(User.location.ilike(f"%{location}%"))
    
    # Apply pagination
    users = query.offset(skip).limit(limit).all()
    
    # Build response with credential information
    result = []
    for user in users:
        # Get public credentials for this user
        credentials_query = db.query(Credential).filter(
            and_(
                Credential.recipient_email == user.email,
                Credential.is_public == True,
                Credential.status == CredentialStatus.ISSUED
            )
        )
        
        # Apply organization filter if specified
        if organization_id:
            credentials_query = credentials_query.filter(
                Credential.organization_id == organization_id
            )
        
        total_credentials = credentials_query.count()
        recent_credentials = credentials_query.order_by(
            desc(Credential.issued_at)
        ).limit(3).all()
        
        # Format recent credentials
        recent_creds_data = []
        for cred in recent_credentials:
            recent_creds_data.append({
                "credential_id": cred.credential_id,
                "title": cred.title,
                "organization_name": cred.organization.name,
                "issued_at": cred.issued_at.isoformat() if cred.issued_at else None,
                "verification_url": cred.verification_url
            })
        
        result.append(EarnerDirectoryEntry(
            id=str(user.id),
            name=f"{user.first_name} {user.last_name}",
            bio=user.bio,
            location=user.location,
            profile_picture=user.profile_picture,
            total_credentials=total_credentials,
            recent_credentials=recent_creds_data
        ))
    
    # Filter out users with no public credentials if organization filter is applied
    if organization_id:
        result = [entry for entry in result if entry.total_credentials > 0]
    
    return result


@app.get("/directory/{user_id}", response_model=EarnerDirectoryEntry)
async def get_earner_profile(
    user_id: str,
    db: Session = Depends(get_db_session)
):
    """Get a specific earner's public profile."""
    
    user = db.query(User).filter(
        and_(
            User.id == user_id,
            User.is_public == True
        )
    ).first()
    
    if not user:
        raise NotFoundError("Earner profile not found or not public")
    
    # Get public credentials
    credentials = db.query(Credential).filter(
        and_(
            Credential.recipient_email == user.email,
            Credential.is_public == True,
            Credential.status == CredentialStatus.ISSUED
        )
    ).order_by(desc(Credential.issued_at)).all()
    
    # Format credentials data
    credentials_data = []
    for cred in credentials:
        credentials_data.append({
            "credential_id": cred.credential_id,
            "title": cred.title,
            "description": cred.description,
            "organization_name": cred.organization.name,
            "organization_logo": cred.organization.logo_url,
            "issued_at": cred.issued_at.isoformat() if cred.issued_at else None,
            "verification_url": cred.verification_url,
            "tags": cred.tags
        })
    
    return EarnerDirectoryEntry(
        id=str(user.id),
        name=f"{user.first_name} {user.last_name}",
        bio=user.bio,
        location=user.location,
        profile_picture=user.profile_picture,
        total_credentials=len(credentials_data),
        recent_credentials=credentials_data
    )


@app.get("/stats")
async def get_recipient_stats(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db_session)
):
    """Get statistics for the current recipient."""
    
    # Get credential counts by status
    total_credentials = db.query(Credential).filter(
        Credential.recipient_email == current_user.email
    ).count()
    
    active_credentials = db.query(Credential).filter(
        and_(
            Credential.recipient_email == current_user.email,
            Credential.status == CredentialStatus.ISSUED,
            or_(
                Credential.expires_at.is_(None),
                Credential.expires_at > datetime.utcnow()
            )
        )
    ).count()
    
    expired_credentials = db.query(Credential).filter(
        and_(
            Credential.recipient_email == current_user.email,
            Credential.expires_at < datetime.utcnow()
        )
    ).count()
    
    public_credentials = db.query(Credential).filter(
        and_(
            Credential.recipient_email == current_user.email,
            Credential.is_public == True
        )
    ).count()
    
    # Get recent activity (last 30 days)
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    recent_credentials = db.query(Credential).filter(
        and_(
            Credential.recipient_email == current_user.email,
            Credential.issued_at >= thirty_days_ago
        )
    ).count()
    
    # Get organizations that issued credentials
    organizations = db.query(Organization).join(Credential).filter(
        Credential.recipient_email == current_user.email
    ).distinct().all()
    
    return {
        "total_credentials": total_credentials,
        "active_credentials": active_credentials,
        "expired_credentials": expired_credentials,
        "public_credentials": public_credentials,
        "recent_credentials": recent_credentials,
        "issuing_organizations": len(organizations),
        "organizations": [
            {
                "id": str(org.id),
                "name": org.name,
                "logo_url": org.logo_url
            }
            for org in organizations
        ]
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

