"""
Verification Service

This service handles credential verification, providing both public and private
verification endpoints, QR code verification, and optional blockchain integration.
"""

from fastapi import FastAPI, Depends, HTTPException, status, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from typing import Optional, Dict, Any, List
from datetime import datetime
import json
import hashlib
import requests
from pathlib import Path

# Import shared modules
import sys
sys.path.append('/home/ubuntu/digital-credentials-platform/backend')

from shared.database import get_db_session, create_tables
from shared.models import Credential, CredentialVerification, VerificationStatus, CredentialStatus, AnalyticsEvent
from shared.auth import get_current_user
from shared.exceptions import NotFoundError, VerificationError
from shared.utils import generate_uuid
from shared.config import settings

# Pydantic models
from pydantic import BaseModel, validator
from enum import Enum


class VerificationRequest(BaseModel):
    credential_id: str
    verification_method: str = "url"  # url, qr_code, api
    
    @validator('credential_id')
    def validate_credential_id(cls, v):
        if not v or len(v.strip()) < 3:
            raise ValueError('Invalid credential ID')
        return v.strip()


class VerificationResponse(BaseModel):
    credential_id: str
    status: str
    valid: bool
    credential_data: Optional[Dict[str, Any]] = None
    verification_details: Dict[str, Any]
    verified_at: datetime
    
    class Config:
        from_attributes = True


class PublicCredentialInfo(BaseModel):
    credential_id: str
    title: str
    description: Optional[str]
    recipient_name: str
    issuer_name: str
    organization_name: str
    issued_at: Optional[datetime]
    expires_at: Optional[datetime]
    status: str
    is_valid: bool
    verification_url: str
    
    class Config:
        from_attributes = True


# Initialize FastAPI app
app = FastAPI(
    title="Digital Credentials Platform - Verification Service",
    description="Service for verifying digital credentials",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for public verification
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Setup templates
templates_dir = Path(__file__).parent / "templates"
templates_dir.mkdir(exist_ok=True)
templates = Jinja2Templates(directory=str(templates_dir))


@app.on_event("startup")
async def startup_event():
    """Initialize database tables on startup."""
    create_tables()


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "verification"}


@app.get("/verify/{credential_id}", response_class=HTMLResponse)
async def verify_credential_page(
    request: Request,
    credential_id: str,
    db: Session = Depends(get_db_session)
):
    """Public verification page for credentials."""
    
    try:
        # Get credential
        credential = db.query(Credential).filter(
            Credential.credential_id == credential_id
        ).first()
        
        if not credential:
            return templates.TemplateResponse(
                "verification_error.html",
                {
                    "request": request,
                    "error": "Credential not found",
                    "credential_id": credential_id
                }
            )
        
        # Check if credential is public or if user has access
        if not credential.is_public:
            return templates.TemplateResponse(
                "verification_private.html",
                {
                    "request": request,
                    "credential_id": credential_id
                }
            )
        
        # Verify credential
        verification_result = await verify_credential_internal(
            credential,
            request.client.host if request.client else "unknown",
            request.headers.get("user-agent", "unknown"),
            "url",
            db
        )
        
        # Get organization and issuer info
        organization = credential.organization
        issuer = credential.issuer
        
        credential_info = {
            "credential_id": credential.credential_id,
            "title": credential.title,
            "description": credential.description,
            "recipient_name": credential.recipient_name,
            "issuer_name": f"{issuer.first_name} {issuer.last_name}",
            "organization_name": organization.name,
            "organization_logo": organization.logo_url,
            "issued_at": credential.issued_at,
            "expires_at": credential.expires_at,
            "status": credential.status.value,
            "is_valid": verification_result["valid"],
            "verification_details": verification_result["verification_details"],
            "credential_data": credential.credential_data if credential.is_public else {},
            "json_ld": credential.json_ld
        }
        
        return templates.TemplateResponse(
            "verification_success.html",
            {
                "request": request,
                "credential": credential_info
            }
        )
        
    except Exception as e:
        return templates.TemplateResponse(
            "verification_error.html",
            {
                "request": request,
                "error": str(e),
                "credential_id": credential_id
            }
        )


@app.post("/api/verify", response_model=VerificationResponse)
async def verify_credential_api(
    request: VerificationRequest,
    client_request: Request,
    db: Session = Depends(get_db_session)
):
    """API endpoint for credential verification."""
    
    # Get credential
    credential = db.query(Credential).filter(
        Credential.credential_id == request.credential_id
    ).first()
    
    if not credential:
        raise NotFoundError("Credential not found")
    
    # Verify credential
    verification_result = await verify_credential_internal(
        credential,
        client_request.client.host if client_request.client else "unknown",
        client_request.headers.get("user-agent", "unknown"),
        request.verification_method,
        db
    )
    
    return VerificationResponse(
        credential_id=credential.credential_id,
        status=credential.status.value,
        valid=verification_result["valid"],
        credential_data=credential.credential_data if credential.is_public else None,
        verification_details=verification_result["verification_details"],
        verified_at=datetime.utcnow()
    )


@app.get("/api/credential/{credential_id}/info", response_model=PublicCredentialInfo)
async def get_credential_info(
    credential_id: str,
    db: Session = Depends(get_db_session)
):
    """Get public information about a credential."""
    
    credential = db.query(Credential).filter(
        Credential.credential_id == credential_id
    ).first()
    
    if not credential:
        raise NotFoundError("Credential not found")
    
    if not credential.is_public:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This credential is private"
        )
    
    # Get related information
    organization = credential.organization
    issuer = credential.issuer
    
    return PublicCredentialInfo(
        credential_id=credential.credential_id,
        title=credential.title,
        description=credential.description,
        recipient_name=credential.recipient_name,
        issuer_name=f"{issuer.first_name} {issuer.last_name}",
        organization_name=organization.name,
        issued_at=credential.issued_at,
        expires_at=credential.expires_at,
        status=credential.status.value,
        is_valid=await is_credential_valid(credential),
        verification_url=credential.verification_url
    )


@app.get("/api/credential/{credential_id}/json-ld")
async def get_credential_json_ld(
    credential_id: str,
    db: Session = Depends(get_db_session)
):
    """Get JSON-LD representation of a credential."""
    
    credential = db.query(Credential).filter(
        Credential.credential_id == credential_id
    ).first()
    
    if not credential:
        raise NotFoundError("Credential not found")
    
    if not credential.is_public:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="This credential is private"
        )
    
    if not credential.json_ld:
        raise NotFoundError("JSON-LD representation not available")
    
    return JSONResponse(content=credential.json_ld)


@app.post("/api/verify/batch")
async def verify_credentials_batch(
    credential_ids: List[str],
    client_request: Request,
    db: Session = Depends(get_db_session)
):
    """Verify multiple credentials in batch."""
    
    if len(credential_ids) > 100:  # Limit batch size
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Maximum 100 credentials can be verified in a single batch"
        )
    
    results = []
    
    for credential_id in credential_ids:
        try:
            credential = db.query(Credential).filter(
                Credential.credential_id == credential_id
            ).first()
            
            if credential:
                verification_result = await verify_credential_internal(
                    credential,
                    client_request.client.host if client_request.client else "unknown",
                    client_request.headers.get("user-agent", "unknown"),
                    "api",
                    db
                )
                
                results.append({
                    "credential_id": credential_id,
                    "status": "verified",
                    "valid": verification_result["valid"],
                    "details": verification_result["verification_details"]
                })
            else:
                results.append({
                    "credential_id": credential_id,
                    "status": "not_found",
                    "valid": False,
                    "details": {"error": "Credential not found"}
                })
                
        except Exception as e:
            results.append({
                "credential_id": credential_id,
                "status": "error",
                "valid": False,
                "details": {"error": str(e)}
            })
    
    return {"results": results}


@app.get("/api/verify/blockchain/{credential_id}")
async def verify_credential_blockchain(
    credential_id: str,
    db: Session = Depends(get_db_session)
):
    """Verify credential using blockchain anchoring."""
    
    credential = db.query(Credential).filter(
        Credential.credential_id == credential_id
    ).first()
    
    if not credential:
        raise NotFoundError("Credential not found")
    
    if not credential.blockchain_hash:
        raise VerificationError("Credential is not anchored on blockchain")
    
    # Verify blockchain hash
    blockchain_result = await verify_blockchain_hash(
        credential.blockchain_hash,
        credential.json_ld
    )
    
    return {
        "credential_id": credential_id,
        "blockchain_verified": blockchain_result["verified"],
        "blockchain_details": blockchain_result,
        "transaction_hash": credential.blockchain_tx_hash
    }


async def verify_credential_internal(
    credential: Credential,
    verifier_ip: str,
    user_agent: str,
    verification_method: str,
    db: Session
) -> Dict[str, Any]:
    """Internal credential verification logic."""
    
    verification_details = {
        "checks_performed": [],
        "warnings": [],
        "errors": []
    }
    
    is_valid = True
    
    # Check credential status
    verification_details["checks_performed"].append("status_check")
    if credential.status == CredentialStatus.REVOKED:
        is_valid = False
        verification_details["errors"].append("Credential has been revoked")
        if credential.revocation_reason:
            verification_details["errors"].append(f"Revocation reason: {credential.revocation_reason}")
    elif credential.status == CredentialStatus.DRAFT:
        is_valid = False
        verification_details["errors"].append("Credential is still in draft status")
    
    # Check expiration
    verification_details["checks_performed"].append("expiration_check")
    if credential.expires_at and credential.expires_at < datetime.utcnow():
        is_valid = False
        verification_details["errors"].append("Credential has expired")
    
    # Check issuer validity
    verification_details["checks_performed"].append("issuer_check")
    if not credential.issuer.is_active:
        verification_details["warnings"].append("Issuer account is inactive")
    
    # Check organization validity
    verification_details["checks_performed"].append("organization_check")
    if not credential.organization.is_verified:
        verification_details["warnings"].append("Issuing organization is not verified")
    
    # Verify JSON-LD integrity if available
    if credential.json_ld:
        verification_details["checks_performed"].append("json_ld_integrity")
        try:
            # Calculate hash of current JSON-LD
            current_hash = hashlib.sha256(
                json.dumps(credential.json_ld, sort_keys=True).encode()
            ).hexdigest()
            
            # Compare with stored hash if available
            if credential.blockchain_hash:
                if current_hash != credential.blockchain_hash:
                    verification_details["warnings"].append("JSON-LD integrity check failed")
        except Exception as e:
            verification_details["warnings"].append(f"JSON-LD verification error: {str(e)}")
    
    # Record verification event
    verification_record = CredentialVerification(
        credential_id=credential.id,
        verifier_ip=verifier_ip,
        verifier_user_agent=user_agent,
        verification_method=verification_method,
        verification_result=VerificationStatus.VALID if is_valid else VerificationStatus.INVALID,
        verification_details=verification_details
    )
    
    db.add(verification_record)
    
    # Record analytics event
    analytics_event = AnalyticsEvent(
        event_type="verify",
        credential_id=credential.id,
        organization_id=credential.organization_id,
        event_data={
            "verification_method": verification_method,
            "result": "valid" if is_valid else "invalid",
            "ip_address": verifier_ip
        },
        ip_address=verifier_ip,
        user_agent=user_agent
    )
    
    db.add(analytics_event)
    db.commit()
    
    return {
        "valid": is_valid,
        "verification_details": verification_details
    }


async def is_credential_valid(credential: Credential) -> bool:
    """Check if a credential is currently valid."""
    
    # Check status
    if credential.status in [CredentialStatus.REVOKED, CredentialStatus.DRAFT]:
        return False
    
    # Check expiration
    if credential.expires_at and credential.expires_at < datetime.utcnow():
        return False
    
    return True


async def verify_blockchain_hash(
    stored_hash: str,
    json_ld_data: Dict[str, Any]
) -> Dict[str, Any]:
    """Verify credential hash against blockchain."""
    
    try:
        # Calculate current hash
        current_hash = hashlib.sha256(
            json.dumps(json_ld_data, sort_keys=True).encode()
        ).hexdigest()
        
        # Compare hashes
        hash_match = stored_hash == current_hash
        
        # In a real implementation, you would also:
        # 1. Query the blockchain to verify the hash exists
        # 2. Check the transaction timestamp
        # 3. Verify the issuer's blockchain identity
        
        # For now, we'll simulate blockchain verification
        blockchain_verified = hash_match  # Simplified check
        
        return {
            "verified": blockchain_verified,
            "hash_match": hash_match,
            "stored_hash": stored_hash,
            "calculated_hash": current_hash,
            "blockchain_timestamp": None,  # Would be fetched from blockchain
            "block_number": None  # Would be fetched from blockchain
        }
        
    except Exception as e:
        return {
            "verified": False,
            "error": str(e)
        }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

