import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar.jsx'
import { Switch } from '@/components/ui/switch.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { 
  Award, 
  Download, 
  Share2, 
  Eye, 
  EyeOff, 
  Calendar, 
  Building, 
  User, 
  Mail,
  MapPin,
  Globe,
  Linkedin,
  Twitter,
  Search,
  Filter,
  ExternalLink,
  Settings,
  BarChart3,
  Shield,
  CheckCircle,
  Clock,
  AlertCircle
} from 'lucide-react'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('credentials')
  const [credentials, setCredentials] = useState([])
  const [profile, setProfile] = useState(null)
  const [stats, setStats] = useState(null)
  const [earners, setEarners] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [loading, setLoading] = useState(true)

  // Mock data for demonstration
  useEffect(() => {
    // Simulate API calls
    setTimeout(() => {
      setProfile({
        id: '1',
        first_name: 'John',
        last_name: 'Doe',
        email: 'john.doe@example.com',
        bio: 'Software developer passionate about continuous learning and professional development.',
        location: 'San Francisco, CA',
        website: 'https://johndoe.dev',
        linkedin_url: 'https://linkedin.com/in/johndoe',
        twitter_url: 'https://twitter.com/johndoe',
        is_public: true,
        total_credentials: 8,
        public_credentials: 6
      })

      setCredentials([
        {
          id: '1',
          credential_id: 'cert-001',
          title: 'AWS Solutions Architect Professional',
          description: 'Advanced certification for designing distributed applications on AWS',
          organization_name: 'Amazon Web Services',
          organization_logo: '/api/placeholder/40/40',
          issuer_name: 'AWS Training Team',
          issued_at: '2024-01-15T00:00:00Z',
          expires_at: '2027-01-15T00:00:00Z',
          status: 'issued',
          is_public: true,
          verification_url: 'https://verify.example.com/cert-001',
          tags: ['cloud', 'architecture', 'aws']
        },
        {
          id: '2',
          credential_id: 'cert-002',
          title: 'React Developer Certification',
          description: 'Professional certification in React.js development',
          organization_name: 'Meta',
          organization_logo: '/api/placeholder/40/40',
          issuer_name: 'Meta Developer Team',
          issued_at: '2023-11-20T00:00:00Z',
          expires_at: null,
          status: 'issued',
          is_public: true,
          verification_url: 'https://verify.example.com/cert-002',
          tags: ['react', 'frontend', 'javascript']
        },
        {
          id: '3',
          credential_id: 'cert-003',
          title: 'Project Management Professional (PMP)',
          description: 'Global standard for project management professionals',
          organization_name: 'Project Management Institute',
          organization_logo: '/api/placeholder/40/40',
          issuer_name: 'PMI Certification Team',
          issued_at: '2023-08-10T00:00:00Z',
          expires_at: '2026-08-10T00:00:00Z',
          status: 'issued',
          is_public: false,
          verification_url: 'https://verify.example.com/cert-003',
          tags: ['project-management', 'leadership']
        }
      ])

      setStats({
        total_credentials: 8,
        active_credentials: 7,
        expired_credentials: 1,
        public_credentials: 6,
        recent_credentials: 2,
        issuing_organizations: 5
      })

      setEarners([
        {
          id: '1',
          name: 'Alice Johnson',
          bio: 'Data scientist with expertise in machine learning and AI',
          location: 'New York, NY',
          total_credentials: 12,
          recent_credentials: [
            { title: 'Machine Learning Engineer', organization_name: 'Google', issued_at: '2024-01-10T00:00:00Z' },
            { title: 'Data Science Professional', organization_name: 'IBM', issued_at: '2023-12-15T00:00:00Z' }
          ]
        },
        {
          id: '2',
          name: 'Bob Smith',
          bio: 'Full-stack developer and cloud architect',
          location: 'Seattle, WA',
          total_credentials: 9,
          recent_credentials: [
            { title: 'Azure Solutions Architect', organization_name: 'Microsoft', issued_at: '2024-01-05T00:00:00Z' },
            { title: 'Kubernetes Administrator', organization_name: 'CNCF', issued_at: '2023-11-20T00:00:00Z' }
          ]
        }
      ])

      setLoading(false)
    }, 1000)
  }, [])

  const formatDate = (dateString) => {
    if (!dateString) return 'No expiration'
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  const getStatusIcon = (status, expiresAt) => {
    if (status === 'revoked') return <AlertCircle className="w-4 h-4 text-red-500" />
    if (expiresAt && new Date(expiresAt) < new Date()) return <Clock className="w-4 h-4 text-orange-500" />
    return <CheckCircle className="w-4 h-4 text-green-500" />
  }

  const getStatusText = (status, expiresAt) => {
    if (status === 'revoked') return 'Revoked'
    if (expiresAt && new Date(expiresAt) < new Date()) return 'Expired'
    return 'Active'
  }

  const shareCredential = (credential, platform) => {
    const shareUrls = {
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${credential.verification_url}`,
      twitter: `https://twitter.com/intent/tweet?text=I just earned: ${credential.title}&url=${credential.verification_url}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${credential.verification_url}`
    }
    
    if (shareUrls[platform]) {
      window.open(shareUrls[platform], '_blank', 'width=600,height=400')
    }
  }

  const filteredEarners = earners.filter(earner =>
    earner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    earner.bio.toLowerCase().includes(searchTerm.toLowerCase()) ||
    earner.location.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your credentials...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Award className="w-8 h-8 text-blue-600 mr-3" />
              <h1 className="text-xl font-bold text-gray-900">My Credentials</h1>
            </div>
            <div className="flex items-center gap-4">
              <Avatar>
                <AvatarImage src="/api/placeholder/32/32" />
                <AvatarFallback>{profile?.first_name?.[0]}{profile?.last_name?.[0]}</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium text-gray-700">
                {profile?.first_name} {profile?.last_name}
              </span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="credentials">My Credentials</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="directory">Earners Directory</TabsTrigger>
            <TabsTrigger value="stats">Statistics</TabsTrigger>
          </TabsList>

          {/* Credentials Tab */}
          <TabsContent value="credentials" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">My Credentials</h2>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </Button>
              </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {credentials.map((credential) => (
                <Card key={credential.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <img 
                          src={credential.organization_logo} 
                          alt={credential.organization_name}
                          className="w-10 h-10 rounded-lg"
                        />
                        <div>
                          <CardTitle className="text-lg">{credential.title}</CardTitle>
                          <p className="text-sm text-gray-600">{credential.organization_name}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        {getStatusIcon(credential.status, credential.expires_at)}
                        <span className="text-xs text-gray-500">
                          {getStatusText(credential.status, credential.expires_at)}
                        </span>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {credential.description}
                    </p>
                    
                    <div className="space-y-2 text-xs text-gray-500">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3 h-3" />
                        <span>Issued: {formatDate(credential.issued_at)}</span>
                      </div>
                      {credential.expires_at && (
                        <div className="flex items-center gap-2">
                          <Clock className="w-3 h-3" />
                          <span>Expires: {formatDate(credential.expires_at)}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex flex-wrap gap-1">
                      {credential.tags?.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex items-center justify-between pt-2">
                      <div className="flex items-center gap-1">
                        {credential.is_public ? (
                          <Eye className="w-4 h-4 text-green-600" />
                        ) : (
                          <EyeOff className="w-4 h-4 text-gray-400" />
                        )}
                        <span className="text-xs text-gray-500">
                          {credential.is_public ? 'Public' : 'Private'}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <Download className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 w-8 p-0"
                          onClick={() => window.open(credential.verification_url, '_blank')}
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 w-8 p-0"
                          onClick={() => shareCredential(credential, 'linkedin')}
                        >
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">First Name</Label>
                        <Input id="firstName" value={profile?.first_name} />
                      </div>
                      <div>
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input id="lastName" value={profile?.last_name} />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" value={profile?.email} disabled />
                    </div>
                    
                    <div>
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea id="bio" value={profile?.bio} rows={3} />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="location">Location</Label>
                        <Input id="location" value={profile?.location} />
                      </div>
                      <div>
                        <Label htmlFor="website">Website</Label>
                        <Input id="website" value={profile?.website} />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="linkedin">LinkedIn</Label>
                        <Input id="linkedin" value={profile?.linkedin_url} />
                      </div>
                      <div>
                        <Label htmlFor="twitter">Twitter</Label>
                        <Input id="twitter" value={profile?.twitter_url} />
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="public-profile">Public Profile</Label>
                        <p className="text-sm text-gray-600">
                          Allow others to see your profile in the earners directory
                        </p>
                      </div>
                      <Switch id="public-profile" checked={profile?.is_public} />
                    </div>
                    
                    <Button>Save Changes</Button>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center">
                      <Avatar className="w-20 h-20 mx-auto mb-4">
                        <AvatarImage src="/api/placeholder/80/80" />
                        <AvatarFallback className="text-lg">
                          {profile?.first_name?.[0]}{profile?.last_name?.[0]}
                        </AvatarFallback>
                      </Avatar>
                      <h3 className="font-semibold">{profile?.first_name} {profile?.last_name}</h3>
                      <p className="text-sm text-gray-600">{profile?.location}</p>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Total Credentials</span>
                        <Badge variant="secondary">{profile?.total_credentials}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Public Credentials</span>
                        <Badge variant="secondary">{profile?.public_credentials}</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Directory Tab */}
          <TabsContent value="directory" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Earners Directory</h2>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Search earners..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64"
                  />
                </div>
              </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredEarners.map((earner) => (
                <Card key={earner.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src="/api/placeholder/40/40" />
                        <AvatarFallback>{earner.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">{earner.name}</CardTitle>
                        <div className="flex items-center gap-1 text-sm text-gray-600">
                          <MapPin className="w-3 h-3" />
                          {earner.location}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {earner.bio}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Credentials</span>
                      <Badge variant="secondary">{earner.total_credentials}</Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Recent Credentials</h4>
                      {earner.recent_credentials.slice(0, 2).map((cred, index) => (
                        <div key={index} className="text-xs text-gray-600">
                          <div className="font-medium">{cred.title}</div>
                          <div>{cred.organization_name}</div>
                        </div>
                      ))}
                    </div>
                    
                    <Button variant="outline" size="sm" className="w-full">
                      View Profile
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Statistics Tab */}
          <TabsContent value="stats" className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Statistics</h2>
            
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Credentials</p>
                      <p className="text-2xl font-bold">{stats?.total_credentials}</p>
                    </div>
                    <Award className="w-8 h-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Active</p>
                      <p className="text-2xl font-bold text-green-600">{stats?.active_credentials}</p>
                    </div>
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Public</p>
                      <p className="text-2xl font-bold text-blue-600">{stats?.public_credentials}</p>
                    </div>
                    <Eye className="w-8 h-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Recent (30d)</p>
                      <p className="text-2xl font-bold text-purple-600">{stats?.recent_credentials}</p>
                    </div>
                    <BarChart3 className="w-8 h-8 text-purple-600" />
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Credential Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Active Credentials</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full" 
                          style={{ width: `${(stats?.active_credentials / stats?.total_credentials) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium">{stats?.active_credentials}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Public Credentials</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{ width: `${(stats?.public_credentials / stats?.total_credentials) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium">{stats?.public_credentials}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Expired Credentials</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-orange-600 h-2 rounded-full" 
                          style={{ width: `${(stats?.expired_credentials / stats?.total_credentials) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium">{stats?.expired_credentials}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App

